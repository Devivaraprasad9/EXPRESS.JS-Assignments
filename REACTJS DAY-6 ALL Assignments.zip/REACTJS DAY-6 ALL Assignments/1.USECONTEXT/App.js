import React, { useState } from 'react';
import Child1 from './Child1';
 
export var userDetailsContext  = React.createContext(null);
 

function App(){

  let userObj = [{ name : "SMITH", age : 30, email : "SMITH@gmail.com"},
  { name : "suman", age : 20, email : "suman9876@gmail.com"},
  { name : "suresh", age : 50, email : "Suresh999@gmail.com"},
  { name : "shreya", age : 55, email : "shreya896@gmail.com"},
];
   
    return (
      <div style={{margin:"10px", border:"2px solid Blue"}}>  
        <h3>This is the Parent Component</h3>    
        <hr/>
        <userDetailsContext.Provider  value={userObj}>
            <Child1 />
        </userDetailsContext.Provider>  
          
      </div>
    );   
}

export default App;