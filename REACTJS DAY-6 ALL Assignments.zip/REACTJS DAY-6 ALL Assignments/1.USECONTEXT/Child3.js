import axios from 'axios';
import { useContext } from 'react';
import { userDetailsContext } from './App';


function Child3(props) {     
    
  let resultArray  = useContext(userDetailsContext).map(item =>{
    return <tr>
          <td>   {item.name}  </td>
          <td>   {item.age}  </td>
          <td>   {item.email}  </td>
          </tr>



  });
 
  return <div style={{margin:"10px", border:"2px solid Red"}}>  
          <h3>This is  Child3 Component</h3>       
          <hr/>
     <table >

     
          <tr>
          <td>  Name  </td>
          <td>  Age  </td>
          <td>  email </td>
          </tr>
          {resultArray}
          </table>
        </div>;
}

export default Child3;