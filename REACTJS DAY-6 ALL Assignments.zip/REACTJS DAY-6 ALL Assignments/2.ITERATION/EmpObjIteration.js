import React from "react";

function EmpObjIteration(){

    let empArray = [
        {empno:5301,ename:'Virat',email:'virat@gmail.com',job:'Developer'},
        {empno:53002,ename:'prasad',email:'prasad@gmail.com',job:'Testing Engineer'},
        {empno:5303,ename:'venkat',email:'venkat@gmail.com',job:'Fianance'},
        {empno:5304,ename:'Dhoni',email:'Dhoni@gmail.com',job:'HR'},
        {empno:5305,ename:'Risab',email:'Risab@gmail.com',job:'Tester'},
    ]
    
    const tableRows = [];

    for (let i = 0; i < empArray.length; i++) {
      const rowData = [];
      for (let key in empArray[i]) {
        rowData .push (<td key={key}>{empArray[i][key]}</td>);
      }
      tableRows.push(<tr key={empArray[i].id}>{rowData}</tr>);
    }

    return (
        <table border="10" cellSpacing="0" width="500" style={ {textAlign:'center', backgroundColor:'pink'}}>

            <tr>
                <th>Employees ID</th>
                <th>Employees Name</th>
                <th>Employees Email</th>
                <th>Employees Job</th>
            </tr>
            {tableRows}
        </table>
    );
  }


export default EmpObjIteration;