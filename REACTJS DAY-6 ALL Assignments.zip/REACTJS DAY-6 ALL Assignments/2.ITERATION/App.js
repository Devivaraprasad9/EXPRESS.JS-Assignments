import React from 'react';
import EmpObjIteration from './EmpObjIteration';
function App(){ 
  return (
      <div>  
      <EmpObjIteration />  
          
      </div>
    );   
}

export default App;