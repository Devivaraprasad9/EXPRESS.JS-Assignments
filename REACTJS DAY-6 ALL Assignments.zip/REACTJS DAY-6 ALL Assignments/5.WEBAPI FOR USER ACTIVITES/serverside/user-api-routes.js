const express = require("express");
const UserModel = require('./models/user-model');
const bcrypt = require("bcrypt")
const router = express.Router();

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await UserModel.findOne({ email, password });
    if (user) {
      res.json({ success: true });
      console.log('Login successful')
    } else {
      res.json({ success: false, });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});


router.post('/register', async (req, res) => {
  
  try {
    
    
      const { name,email, password ,securityAnswer} = req.body;
      const user = new UserModel({
      securityAnswer,
      name,
      email,
      password
    });

    await user.save();
    console.log('New user Into the Database')
    res.json({success:true}) 
  
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});


router.post('/resetPassword', async (req, res) => {
  const { email, securityAnswer,newPassword } = req.body;

  try {
    const user = await UserModel.findOne({ email, securityAnswer });
    if (user) {
      // Update password in the database
      user.password = newPassword;
      await user.save();
      res.json({ message: true });
    } 
    else {
      res.json({ message: false });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;