import React, {useState} from 'react';
import { useLocation, useNavigate} from "react-router-dom";
import axios from 'axios';

function Login() {   

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    let navigate = useNavigate();
    let location = useLocation();
  
    const handleLogin = async () => {
      try {
        const queryString = location.search;
        let strReturnUrl  =  new URLSearchParams(queryString).get('returnUrl');
        const response = await axios.post('http://localhost:3007/api/login', { email, password });
        if(strReturnUrl == null)
        {
          strReturnUrl = "/";
        }
        if (response.data.success) {

          let token = "ASJDFJF87ADF8745LK4598SAD7FAJSDF45JSDLFKAS";
          sessionStorage.setItem('user-token', token);

          navigate(strReturnUrl)
          alert('Login successful');
        } 
        else {
         alert('Invalid credentials  or email is not registered  ');
        }
      } catch (error) {
        console.error('Error during login:', error.message);
      }
    };
  
    return (
      <div align='center' style={ {backgroundColor:'aqua'}} >
        <h1 style={ {paddingTop:'50px'}}>Login Page</h1>
        Enter Username/Email: <input type="text" placeholder="email" value={email} onChange={(e) => setEmail(e.target.value)} style={ {margin:'10px'}}/> <br/>
        Enter Password: <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} style={ {margin:'10px'}}/><br/>
        <button onClick={handleLogin}>Login</button><br/>
        <a href='/ForgetPassword'>Forgot Password ???</a>

        <p style={ {paddingBottom:'50px'}}>If you don't have an account, Please <a href='/Register'>click here</a> to Register!</p>
      </div>
    );
  }
  
  

export default Login;
