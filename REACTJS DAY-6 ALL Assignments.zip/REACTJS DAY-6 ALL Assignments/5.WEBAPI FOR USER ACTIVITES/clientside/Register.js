import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  let navigate = useNavigate();

  const handleRegister = async () => {
       
    try {
    
      await axios.post('http://localhost:3007/api/register', {name, email, password,securityAnswer });
      
      alert('User Added to the Database and Login with email and Password ');
      navigate('/Login')
      }
  
      catch (error) {
      console.error('Registration failed', error.response.data.message);
    }
  };

  return (
    <div align='center' style={ {backgroundColor:'aqua'}}>
      <h2 style={ {paddingTop:'50px'}}>Register</h2>
      Name: <input type="text" placeholder="name" onChange={(e) => setName(e.target.value)} style={ {margin:'10px'}}/><br/>
      Email: <input type="email" placeholder="Email" onChange={(e) => setEmail(e.target.value)} style={ {margin:'10px'}}/><br/>
      password: <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} style={ {margin:'10px'}}/><br/>
      What is Your Nickname? <input type="securityAnswer" placeholder="securityAnswer" onChange={(e) => setSecurityAnswer(e.target.value)} style={ {margin:'10px'}}/><br/>
      <button onClick={handleRegister} >Register</button> 
      <p style={ {paddingBottom:'50px'}} >If you an Account,please <a href='/Login'> click here</a>  to Login!</p>
    </div>
  );
}

export default Register;