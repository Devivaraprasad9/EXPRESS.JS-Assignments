 
import React from 'react';
function App() 
{      
      return(
        <>
          <h1 align='center'>This is Home</h1>   
          <h1 align='center'>Just for validation</h1>   
        </>
        );
}

export default App;