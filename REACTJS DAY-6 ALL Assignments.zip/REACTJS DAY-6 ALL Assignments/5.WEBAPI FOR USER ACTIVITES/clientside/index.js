import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import Login from './Login'
import Register from './Register';
import ForgetPassword from './ForgetPassword';
import App from './App';


const routing = (
  <Router>
    <h3 style={{ textAlign: "center" }}>Routing Implementation using React JS Applications</h3>
    <hr />
    <div style={{ textAlign: "center", }}>|
      <Link to='/'>home</Link> | 
      <Link to="/Login">Login</Link> | 
      <Link to="/Register">Register</Link> | 
      <Link to="/ForgetPassword">forget Password</Link> | 
      
    </div>
    <hr />
    <Routes>
        <Route path="/" element={<App/>} />
        <Route path="/Register" element={<Register/>} />
        <Route path="/Login" element={<Login />} />
        <Route path="/ForgetPassword" element={<ForgetPassword />} />
    </Routes>



  </Router>
);


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {routing}
  </React.StrictMode>
);