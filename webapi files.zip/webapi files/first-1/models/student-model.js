//Import  Mongoose Module
var mongoose = require('mongoose');

// Connect to Mongodb  database(testDb is database name)
mongoose.connect('mongodb://127.0.0.1:27017/category');

// Create  schema
var Schema = mongoose.Schema;

// Schema properties should be match mongodb collection properites
var StudentModelSchema = new Schema(
    {   Rollno: Number, 
        Firstame : String, 	
        Lastname : String ,
        Phoneno : Number,
        Fathername:String  }, 
    { versionKey: false  } );

// Create Model Object	
// "depts"   --- collection name in mongodb
var StudentModel = mongoose.model('students', StudentModelSchema );

// Exporting DeptModel 
module.exports = StudentModel;