import React, { useState } from 'react';
import ProductsList from './ProductsList';

function App() {
  const [selectedCategory, setSelectedCategory] = useState('');

  function handleCategoryChange (event) {
    setSelectedCategory(event.target.value);
  };

  function handleShowAllProducts() {
    setSelectedCategory('');
  };

  return (
    <>
      <h3 align="center">Welcome to React Applications</h3>
      <hr />

      <div>
        <label htmlFor="category">Select a category:</label>
        <select id="category" value={selectedCategory} onChange={handleCategoryChange}>
          <option value="">All Products</option>
          <option value="Mobiles">Mobiles</option>
          <option value="Laptops">Laptops</option>
          {/* Add more options as needed */}
        </select>

        <button onClick={handleShowAllProducts}>Show All Products</button>

        {selectedCategory !== '' ? (
          <ProductsList category={selectedCategory} />
        ) : (
          <ProductsList />
        )}
      </div>
    </>
  );
}

export default App;
