import React from 'react';

function TodoList({ todos, onDeleteTask }) {
    
  return (
    <table border="2" width="700" cellSpacing="0" cellPadding="5">
      <thead>
        <tr>
          <th>Task</th>
        </tr>
      </thead>
      <tbody>
        {todos.map((todo, index) => (
          <tr key={index}>
            <td style={{ position: 'relative', paddingRight: '40px' }}>
              {todo}
              <img
                src="images/1.jpg" 
                alt="Delete"
                width={30}
                style={{
                  cursor: 'pointer',
                  position: 'absolute',
                  top: '50%',
                  right: 0,
                  transform: 'translateY(-50%)',
                }}
                onClick={() => onDeleteTask(index)}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default TodoList;
