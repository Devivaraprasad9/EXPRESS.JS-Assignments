// TodoItem.js
import React, { useState } from 'react';
import TodoList from './TodoList';

function TodoItem() {
  const [task, setTask] = useState('');
  const [todos, setTodos] = useState([]);

 
  function handleInputChange (event) {
    setTask(event.target.value);
  };

  function handleAddTask() {
    if (task.trim() !== '') {
      setTodos([...todos, task]);
      setTask('');
    }
  };

  function handleDeleteTask(index) {
    const newTodos = [...todos];
    newTodos.splice(index, 1);
    setTodos(newTodos);
  };

  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <input
          type="text"
          placeholder="Enter your task"
          value={task}
          onChange={handleInputChange}
          style={{ marginRight: '5px', flex: '0.5' }}
        />
        <input type="button" value="Add Task" onClick={handleAddTask} />
      </div>

      <TodoList todos={todos} onDeleteTask={handleDeleteTask} />
    </>
  );
}

export default TodoItem;
