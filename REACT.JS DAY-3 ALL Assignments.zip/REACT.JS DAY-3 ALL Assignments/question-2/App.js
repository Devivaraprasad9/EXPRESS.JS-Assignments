import React from 'react';
import TodoItem from './TodoItem'




function App() {
  return (
    <>
      <h3 align="center">Welcome to REACT Examples </h3>
      <hr />
     
      <TodoItem />
    </>
  );
}

export default App;