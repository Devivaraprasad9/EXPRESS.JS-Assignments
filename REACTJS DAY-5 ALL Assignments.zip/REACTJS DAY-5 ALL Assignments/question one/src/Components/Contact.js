function Contact()
{    
    return <div style={{backgroundColor:'LightBlue', padding: '10px'}}>
    <h1>Contact Page</h1>  
    <p>This page provides contact details of compnay. This page provides contact details of compnay.This page provides contact details of compnay.This page provides contact details of compnay.This page provides contact details of compnay. </p>
    <p>This page provides contact details of compnay. This page provides contact details of compnay.This page provides contact details of compnay.This page provides contact details of compnay.This page provides contact details of compnay. </p>
    </div> 
    
}  

export default Contact;