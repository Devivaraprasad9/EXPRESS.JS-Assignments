import React from 'react';





function App() {
  return (
    <div style={{ textAlign: "center" }} >
      <h3>Welcome to SPA using React JS</h3>
      <img src="/Images/3.jpg" width="100%" height="550" alt="Alternate text" />
    </div>
  );
}

export default App;