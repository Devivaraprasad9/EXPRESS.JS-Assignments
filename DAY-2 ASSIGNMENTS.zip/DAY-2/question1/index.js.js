var express = require("express");

var app = express();   // Creates an express application

app.set("view engine", "ejs");

app.use(express.static('public'));


app.get("/", function (req, res) {

    let dataObj = {};
    dataObj.deptObj = {id:1,email:"george.bluth@reqres.in",first_name :"George",last_name:"Bluth",}
    dataObj.deptObj1 = {id1:2,email1:"janet.weaver@reqres.in",first_name1:"Janet",last_name1:"Weaver"},
    dataObj.deptObj2 ={id:3,email:"emma.wong@reqres.in",first_name:"Emma",last_name:"Wong"},
    dataObj.deptObj3 = {id:4,email:"eve.holt@reqres.in",first_name:"Eve",last_name:"Holt"},
    dataObj.deptObj4 = {id:5,email:"charles.morris@reqres.in",first_name:"Charles",last_name:"Morris"},
    dataObj.deptObj5 = {id:6,email:"tracey.ramos@reqres.in",first_name:"Tracey",last_name:"Ramos"}
  
  
  
    res.render("home", dataObj);
});

var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");