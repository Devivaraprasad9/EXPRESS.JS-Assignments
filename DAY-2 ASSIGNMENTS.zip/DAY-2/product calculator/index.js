var express = require("express");
var bodyParser = require("body-parser");  // npm i body-parser

// Creates an express application
var app = express();   

app.use(express.static('public'));

// Confgiure the middleware
app.use(bodyParser.urlencoded({extended : false}));

app.set("view engine", "ejs");

app.get("/", function (req, res) {   
    res.render("home", {});
});

app.get("/Login", function (req, res) {       
    res.render("login", {total:"" });
});

app.post("/Login", function (req, res) {   
    
    let name = req.body.t0;
    let price = req.body.t1;
    let qnty = req.body.t2;
    total = price*qnty;
    res.render("login", {total}); 
});



var server = app.listen(3005, function () { });
console.log("Express Server Application is started. Browser at the URL: http://localhost:3005/");