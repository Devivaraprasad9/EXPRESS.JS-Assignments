import React from 'react';
import AjaxDemo3 from './AjaxDemo3';




function App() {
  return (
    <>
      <h3 align="center">Welcome to REACT Examples </h3>
      <hr />
     
      <AjaxDemo3 />
    </>
  );
}

export default App;