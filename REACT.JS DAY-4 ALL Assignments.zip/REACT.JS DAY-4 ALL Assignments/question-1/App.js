import React from 'react';
import AjaxDemo2 from './AjaxDemo2';




function App() {
  return (
    <>
      <h3 align="center">Welcome to REACT Examples </h3>
      <hr />
     
      <AjaxDemo2 />
    </>
  );
}

export default App;