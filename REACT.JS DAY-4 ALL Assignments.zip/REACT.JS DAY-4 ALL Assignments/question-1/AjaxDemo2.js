import axios from 'axios';
import { useState } from 'react';

function AjaxDemo2() {   

  const [empArray, setEmpArray] = useState([]);

  function getDataButton_click() {

      let url = "http://localhost:4300/data";
      axios.get(url).then( (resData) => 
      {
        console.log(resData.data.status);
        setEmpArray(resData.data);
      });
  }

  


  return (
    <div style={{"padding":"5px"}}> 

      <h3>AJAX Programming in React JS using JSON- Server</h3>
      <hr/>
      <input type="button" onClick={getDataButton_click} value="Get Data" />      
      <hr/>
      <div className='container mt-4'>
      <h2>Employee Details</h2>
      <div className='row'>
        {empArray.map(item => (
        <div className="card" style={ {'borderRadius':'20px','margin':'10px'}}>
          <div className="card-body" >
            <img src="images/photo.jpeg" width="80px"height="100px"  /><br/>
            
            <strong>{item.employee_name}</strong><br/>
            Salary: {item.employee_salary}<br/>
            Age: {item.employee_age}
            
          </div>
        </div>
        ))}
      </div>
    </div>

               
        
    </div>
  );
}
export default AjaxDemo2;