import axios from 'axios';
import { useState } from 'react';

function AjaxDemo3() {   

   const [deptsArray, setDeptsArray] = useState([]);


  function getDataButton_click() {

      let url = "http://localhost:4300/data";
      axios.get(url).then( (resData) => 
      {       
        setDeptsArray(resData.data);
      });
  }


  let resultArray = deptsArray.map(item => 
    {
      return <tr>
          <td>{item.id}</td>
          <td>{item.employee_name}</td>
          <td>{item.employee_salary}</td>
          <td>{item.employee_age}</td>
      </tr>;
    });


  return (
    <div style={{"padding":"5px"}}> 

      <h3>AJAX Programming in React JS using Axios Package (JSON Server)</h3>
      <hr/>


      <input type="button" onClick={getDataButton_click} 
               value="Get Data" />

      <hr/>

      <table  border="2" cellSpacing="0" width="500">
          <tr>
            <th>ID Number</th>
            <th>Employee Name</th>
            <th>Employee salary</th>
            <th>Employee age</th>
          </tr>
          {resultArray} 
      </table>         

    </div>
  );
}

export default AjaxDemo3;