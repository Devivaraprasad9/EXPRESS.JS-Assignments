const express = require("express");
const ProductstModel = require('./models/product-model');
const router = express.Router();

// Read All
router.get("/products", async function (req, res) {

    let result = await ProductstModel.find({}, { "_id": 0 });

    try {
        console.log("[Read All] - No. of  items get from database : " + result.length);
        res.send(result);
    }
    catch (error) {
        // sending error details to client
        res.status(500).send(error);    
    }
});

// Read Single
router.get("/products/:id", async function(req, res)
{
    var pno =  req.params.id;   	    
    let result  =  await ProductstModel.findOne({ prodid: pno}, {"_id":0});         
    console.log("[Read Single] - " + JSON.stringify(result));
    res.send(result);     
});


// Create 
router.post('/products',  async  function (req,res)
{ 
        var productObj  = new  ProductstModel({ 
                prodid : parseInt(req.body.prodid),	
                Name  :  req.body.Name,
                price   : req.body.price,
                quantity:req.body.quantity,
                makeBy:req.body.makeBy ,
                madeIn:req.body.madeIn 
             });

        // Logic to insert new dept in database
        let newObj  =  await  productObj.save(); 
		
		var result = {};
		result.status  = "Record inserted in Database";
		console.log("[Create] - Record inserted in Database");
		res.send(result);           
});


// Update
router.put('/products',  async function (req,res)
{ 
        var productObj  = {};
        productObj.prodid = parseInt(req.body.prodid);
        productObj.Name =  req.body.Name;
        productObj.price =  req.body.price; 
        productObj.quantity =  req.body.quantity; 
        productObj.makeBy =  req.body.makeBy; 
        productObj.madeIn =  req.body.madeIn; 

        // Logic to insert new dept in database
        let Result  = await  ProductstModel.findOneAndUpdate(  {prodid:productObj.prodid}, {  $set : productObj});
 
		var result = {};
		result.status  = "Record updated in Database";
		console.log("[Update] - Record updated in Database");
		res.send(result);	
});

// Delete
router.delete('/products/:id',async function (req,res)
{  
    var pno =  req.params.id;   
    let resResult  =  await  ProductstModel.findOneAndDelete({ prodid: pno}); 

	var result = {};
	result.status  = "Record deleted from Database";
	console.log("[Delete] - Record deleted from Database");
	res.send(result);
       
});



module.exports = router;