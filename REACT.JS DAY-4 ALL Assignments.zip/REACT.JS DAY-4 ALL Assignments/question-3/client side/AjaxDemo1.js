import axios from 'axios';
import { useState } from 'react';

function AjaxDemo1() {

  const [customersArray, setCustomersArray] = useState([]);
  const [prodid, setprodid] = useState("");
  const [Name, setName] = useState("");
  const [price, setprice] = useState("");
  const [quantity, setquantity] = useState("");
  


  function getDataButton_click() {

    let url = "http://localhost:3005/api/products";
    axios.get(url).then((resData) => {
      console.log(resData.data);
      setCustomersArray(resData.data);
    });
  }


  function addDataButton_click() {
    
    let deptObj = {};
    deptObj.prodid =prodid;
    deptObj.Name = Name;
    deptObj.price = price;
    deptObj.quantity = quantity;

    let url = "http://localhost:3005/api/products";
    axios.post(url, deptObj).then( (resData) => 
    {       
      alert(resData.data);
      getDataButton_click();
    });

   
    clearFields();
}

function clearFields()
{
    setprodid("");
    setquantity("");
    setName("");
    setprice("");
     
}

function updateDataButton_click() {
    
  let deptObj = {};
  deptObj.prodid =prodid;
  deptObj.Name = Name;
  deptObj.price = price;
  deptObj.quantity = quantity;

  let url = "http://localhost:3005/api/products";
  axios.put(url, deptObj).then( (resData) => 
  {       
    alert(resData.data);
    getDataButton_click();
  });

 
  clearFields();
}

function clearFields()
{
  setprodid("");
  setquantity("");
  setName("");
  setprice("");
   
}




function deleteData_click(pno) {

  let flag = window.confirm("Are you sure want to delete?");    
  if(  flag === false   )
  {
      return;
  }

  let url = "http://localhost:3005/api/products/" + pno;
  axios.delete(url).then( (resData) => 
  {       
    alert(resData.data.status);
    getDataButton_click();
  });


}

let resultArray = customersArray.map((item) => {
  return (
    <tr key={item.prodid}>
      <td>{item.prodid}</td>
      <td>{item.Name}</td>
      <td>{item.price}</td>
      <td>{item.quantity}</td>
      <td>
        <a
          href="javascript:void(0);"
          onClick={() => deleteData_click(item.prodid)}
        >
          <img src="images/1.jpg" width="20" />
        </a>
      </td>
      <td>
        <input
          type="button"
          onClick={() => selectDataForUpdate(item)}
          value="select Data"
        />
      </td>
    </tr>
  );

  function selectDataForUpdate(item) {
    // Capture the data of the selected product
    setprodid(item.prodid);
    setName(item.Name);
    setprice(item.price);
    setquantity(item.quantity);
  }


});
  

  

  return (
    <div style={{ "border": "2px solid blue", "padding": "10px", "padding-bottom": "15px", "backgroundColor": "lightyellow" }}>


      <h3>AJAX Programming in React JS using Axios Package</h3>
      <hr />
      <input type="text" placeholder="ENTER ID" value={prodid} onChange={(e) => setprodid(e.target.value)} />
      <input type="text" placeholder="ENTER NAME" value={Name} onChange={(e) => setName(e.target.value)} />
      <input type="text" placeholder="ENTER PRICE" value={price} onChange={(e) => setprice(e.target.value)} />
      <input type="text" placeholder="ENTER Quantity" value={quantity} onChange={(e) => setquantity(e.target.value)} />
      
      <hr />

      <input type="button" onClick={getDataButton_click}
        value="Get Data" />
      <input type="button" onClick={addDataButton_click} value="Add Data" />
      <input type="button" onClick={updateDataButton_click} value="Update Data" />

      <hr />

      <table border="2" cellSpacing="0" width="500">
        <tr>
          <th>product id</th>
          <th>Name</th>
          <th>price</th>
          <th>quantity</th>
        </tr>
        {resultArray}
      </table>

    </div>
  );
}

export default AjaxDemo1;