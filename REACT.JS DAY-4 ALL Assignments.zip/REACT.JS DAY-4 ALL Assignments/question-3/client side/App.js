import React from 'react';
import AjaxDemo1 from './AjaxDemo1';




function App() {
  return (
    <>
      <h3 align="center">Welcome to REACT Examples </h3>
      <hr />
     
      <AjaxDemo1 />
    </>
  );
}

export default App;