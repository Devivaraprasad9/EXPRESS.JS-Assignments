import BankApp from './Component/Bankapp.js'

function App() 
{      
      return(
        <>
             <BankApp  />
        </>
        );
}

export default App;