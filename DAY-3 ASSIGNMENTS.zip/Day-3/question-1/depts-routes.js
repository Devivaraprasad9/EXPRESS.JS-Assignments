const express = require("express");
const router = express.Router();

router.get("/AllDepts", function (req, res) {

    let dataObj = {};    
    dataObj.deptsArray = [
        { pid: 1, pname: "samsung-tv", price: 12500, quantity :1700, category: "electronics" },
        { pid: 2, pname: "oneplus-tv", price: 15500, quantity :150, category: "electronics" },
        { pid: 3, pname: "realme-mobile", price: 13000, quantity :1200, category: "electronics"  },
        { pid: 4, pname: "L.G-fridge", price: 12500, quantity :5070, category: "electronics"  },
        { pid: 5, pname: "oppo-mobile", price: 22500, quantity :280, category: "electronics"  },
        { pid: 6, pname: "vivo-mobile", price: 19500, quantity :999, category: "electronics"  },
        { pid: 7, pname: "mens-denin-shirt", price: 1499, quantity :867, category: "clothes"  },
        { pid: 8, pname: "mens-pep-jeans", price: 2599, quantity :555, category: "clothes"  },
        { pid: 9, pname: "womens-top", price: 899, quantity :970, category: "clothes"  },
        { pid: 10, pname: "womens-t-shirts", price: 999, quantity :1270, category: "clothes"  },
        
    ];

    res.render("showalldepts", dataObj);
});

router.get("/GetDeptById/:id", function (req, res) {

   // console.log("Requested pid : " + req.params.id);

   var deptsArray = [
    { pid: 1, pname: "samsung-tv", price: 12500, quantity :1700, category: "electronics" },
        { pid: 2, pname: "oneplus-tv", price: 15500, quantity :150, category: "electronics" },
        { pid: 3, pname: "realme-mobile", price: 13000, quantity :1200, category: "electronics"  },
        { pid: 4, pname: "L.G-fridge", price: 12500, quantity :5070, category: "electronics"  },
        { pid: 5, pname: "oppo-mobile", price: 22500, quantity :280, category: "electronics"  },
        { pid: 6, pname: "vivo-mobile", price: 19500, quantity :999, category: "electronics"  },
        { pid: 7, pname: "mens-denin-shirt", price: 1499, quantity :867, category: "clothes"  },
        { pid: 8, pname: "mens-pep-jeans", price: 2599, quantity :555, category: "clothes"  },
        { pid: 9, pname: "womens-top", price: 899, quantity :970, category: "clothes"  },
        { pid: 10, pname: "womens-t-shirts", price: 999, quantity :1270, category: "clothes"  },
        
    ];

    let id = req.params.id;
    let dataObj = {};    
    dataObj.deptObj = deptsArray.find( item => item.pid == id );

    res.render("deptdetails", dataObj);
});

module.exports = router;