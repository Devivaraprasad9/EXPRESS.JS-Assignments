const express = require("express");
const router = express.Router();

router.get("/clothes", function (req, res) { 
    
    let dataObj = {};    
    dataObj.deptsArray = [
        { pid: 7, pname: "mens-denin-shirt", price: 1499, quantity :867, category: "clothes"  },
        { pid: 8, pname: "mens-pep-jeans", price: 2599, quantity :555, category: "clothes"  },
        { pid: 9, pname: "womens-top", price: 899, quantity :970, category: "clothes"  },
        { pid: 10, pname: "womens-t-shirts", price: 999, quantity :1270, category: "clothes"  },
        
        
    ];
    


    res.render("clothes", dataObj);
});

router.post("/clothes", function (req, res) {   
    var deptsArray = [
        { pid: 7, pname: "mens-denin-shirt", price: 1499, quantity :867, category: "clothes"  },
        { pid: 8, pname: "mens-pep-jeans", price: 2599, quantity :555, category: "clothes"  },
        { pid: 9, pname: "womens-top", price: 899, quantity :970, category: "clothes"  },
        { pid: 10, pname: "womens-t-shirts", price: 999, quantity :1270, category: "clothes"  },
            
        ];
        let id = req.query.id;
        let dataObj = {};    
        dataObj.deptObj = deptsArray.find( item => item.pid == id );
        res.render("clothes", dataObj);
});



module.exports = router;