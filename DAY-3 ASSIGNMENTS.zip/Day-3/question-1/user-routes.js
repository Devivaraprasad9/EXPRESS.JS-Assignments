const express = require("express");
const router = express.Router();

router.get("/Login", function (req, res) { 
    
    let dataObj = {};    
    dataObj.deptsArray = [
        { pid: 1, pname: "samsung-tv", price: 12500, quantity :1700, category: "electronics" },
        { pid: 2, pname: "oneplus-tv", price: 15500, quantity :150, category: "electronics" },
        { pid: 3, pname: "realme-mobile", price: 13000, quantity :1200, category: "electronics"  },
        { pid: 4, pname: "L.G-fridge", price: 12500, quantity :5070, category: "electronics"  },
        { pid: 5, pname: "oppo-mobile", price: 22500, quantity :280, category: "electronics"  },
        { pid: 6, pname: "vivo-mobile", price: 19500, quantity :999, category: "electronics"  },
        
        
    ];
    


    res.render("login", dataObj);
});

router.post("/Login", function (req, res) {   
    var deptsArray = [
        { pid: 1, pname: "samsung-tv", price: 12500, quantity :1700, category: "electronics" },
            { pid: 2, pname: "oneplus-tv", price: 15500, quantity :150, category: "electronics" },
            { pid: 3, pname: "realme-mobile", price: 13000, quantity :1200, category: "electronics"  },
            { pid: 4, pname: "L.G-fridge", price: 12500, quantity :5070, category: "electronics"  },
            { pid: 5, pname: "oppo-mobile", price: 22500, quantity :280, category: "electronics"  },
            { pid: 6, pname: "vivo-mobile", price: 19500, quantity :999, category: "electronics"  },
            
        ];
        let id = req.params.id;
        let dataObj = {};    
        dataObj.deptObj = deptsArray.find( item => item.pid == id );
        res.render("login", dataObj);
});



module.exports = router;