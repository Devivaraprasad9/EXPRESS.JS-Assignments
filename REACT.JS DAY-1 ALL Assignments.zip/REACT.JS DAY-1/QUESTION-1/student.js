function student(){
        let sid=10;
        let sname='DEVA';
        let course='maths';
        let age=24;
        let total=100;
        return(
            <>
            <h3>Student Details</h3>
            <div><table border="4" >
                <tr><td>Student ID :</td> <td>{sid}</td></tr>
                <tr><td>Student Name :</td> <td>{sname}</td></tr>
                <tr><td>Student Course :</td> <td>{course}</td></tr>
                <tr><td>Student Age :</td> <td>{age}</td></tr>
                <tr><td>Student Total Marks :</td> <td>{total}</td></tr>
            </table>
            </div>
            </>
        )
}
  export default student;