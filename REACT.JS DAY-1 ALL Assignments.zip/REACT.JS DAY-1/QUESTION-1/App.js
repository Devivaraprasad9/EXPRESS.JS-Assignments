import React from 'react';
import Student from './student';

function App() {
  return (
    <>
      <h3 align="center">Welcome to QUESTION-1</h3>
      <hr />

       <Student />
    </>
  );
}

export default App;