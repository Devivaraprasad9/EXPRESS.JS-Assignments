import React from 'react';
import Doctorlist from './doctorlist'

function App() {
  return (
    <>
      <h3 align="center">Welcome to QUESTION-2</h3>
      <hr />
      <Doctorlist />
      
    </>
  );
}

export default App;