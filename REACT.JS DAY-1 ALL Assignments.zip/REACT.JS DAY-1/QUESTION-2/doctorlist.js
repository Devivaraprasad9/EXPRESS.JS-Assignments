function doctorlist(){
    let docsArray = [
        { doctorid: 101, doctorName: "sharma", designation: "Neuro",exp:'10 Years',contNumber:111111 },
        { doctorid: 102, doctorName: "kohli", designation: "cardi0logist",exp:'20 Years',contNumber:222222 },
        { doctorid: 103, doctorName: "Dhoni", designation: "Neurolist",exp:'30 Years',contNumber:33333 },
        { doctorid: 104, doctorName: "Risab pant", designation: "RMP",exp:'5 Years',contNumber:444444 },
        { doctorid: 105, doctorName: "axar patel", designation: "Psychiatrists",exp:'12 Years',contNumber:555555 },
      ];
    let result = docsArray.map((item) => {
        return <tr>
          <td>   {item.doctorid}  </td>
          <td>   {item.doctorName}  </td>
          <td>   {item.designation}  </td>
          <td>   {item.exp}  </td>
          <td>   {item.contNumber}  </td>
        </tr>
      });
      return(
        <>
        <div>
        <h3>Doctor Details</h3>
        <table border="2" width="300" cellspacing="0" cellpadding="5">
          <tr>
            <th>Doctor ID</th>
            <th>Doctor Name</th>
            <th>Designation</th>
            <th>Experience</th>
            <th>Contact Number</th>
          </tr>
          {result}
        </table>
      </div>
      </>
    )
 }
 export default doctorlist;