import React from 'react';
import DeptList from './deptlist';


function App() {
  return (
    <>
      <h3 align="center">Welcome to QUESTION-3 on employee details </h3>
      <hr />
      <DeptList />
      
    </>
  );
}

export default App;