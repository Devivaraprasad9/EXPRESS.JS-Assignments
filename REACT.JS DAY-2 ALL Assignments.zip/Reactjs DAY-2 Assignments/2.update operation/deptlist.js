import { useState } from "react";

function DeptList() {
    const [deptsArray, setDeptsArray] = useState([]);
    const [deptno, setDeptno] = useState("");
    const [dname, setDname] = useState("");
    const [loc, setLoc] = useState("");
    const [editDeptno, setEditDeptno] = useState("");

    function getDeptsButton_click() {
        let tempArray = [
            { deptno: 10, dname: "Accounts", loc: "Hyd" },
            { deptno: 20, dname: "Sales", loc: "Pune" },
            { deptno: 30, dname: "Marketing", loc: "Hyd" },
            { deptno: 40, dname: "Operations", loc: "Chennai" },
        ];

        setDeptsArray(tempArray);
    }

    function addDeptButton_click() {
        let tempArray = [...deptsArray];

        if (editDeptno) {
        
            let index = tempArray.findIndex(item => item.deptno === editDeptno);
            tempArray[index] = { deptno, dname, loc };
        } else {
            // Adding new department
            let deptObj = { deptno, dname, loc };
            tempArray.push(deptObj);
        }

        setDeptsArray(tempArray);

    
        setDeptno("");
        setDname("");
        setLoc("");
        setEditDeptno("");
    }

    function deleteDept_click(dno) {
        let tempArray = [...deptsArray];
        let index = tempArray.findIndex(item => item.deptno === dno);
        tempArray.splice(index, 1);
        setDeptsArray(tempArray);
    }

    function updateDept_click(dno) {
    
        let departmentToEdit = deptsArray.find(item => item.deptno === dno);

    
        setDeptno(departmentToEdit.deptno);
        setDname(departmentToEdit.dname);
        setLoc(departmentToEdit.loc);

    
        setEditDeptno(dno);
    }

    let resultArray2 = deptsArray.map((item) => {
        return <tr key={item.deptno}>
            <td>   {item.deptno}  </td>
            <td>   {item.dname}  </td>
            <td>   {item.loc}  </td>
            <td>
                <a href="javascript:void(0);" onClick={() => updateDept_click(item.deptno)}>Update</a>
            </td>
            <td>
                <a href="javascript:void(0);" onClick={() => deleteDept_click(item.deptno)}>Delete</a>
            </td>
        </tr>
    });

    return (
        <>
            <h3>Working with State -- CRUD Operations on Array of Objects</h3>
            <hr />

            <input type="text" placeholder="Dept Number" value={deptno} onChange={(e) => setDeptno(e.target.value)} />
            <input type="text" placeholder="Dept Name" value={dname} onChange={(e) => setDname(e.target.value)} />
            <input type="text" placeholder="Dept Location" value={loc} onChange={(e) => setLoc(e.target.value)} />
            <hr />
            <input type="button" onClick={getDeptsButton_click} value="Get Depts" />
            <input type="button" onClick={addDeptButton_click} value={editDeptno ? "Update Dept" : "Add Dept"} />
            <hr />

            <table border="2" width="400" cellSpacing="0" cellPadding="5">
                <thead>
                    <tr>
                        <th>Dept Number</th>
                        <th>Dept Name</th>
                        <th>Location</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {resultArray2}
                </tbody>
            </table>
        </>
    );
}

export default DeptList;
