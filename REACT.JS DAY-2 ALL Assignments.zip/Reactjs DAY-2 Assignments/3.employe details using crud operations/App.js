import React from 'react';
import Emplist from './emplist';


function App() {
  return (
    <>
      <h3 align="center">Welcome to QUESTION-3 on employee details </h3>
      <hr />
      <Emplist />
      
    </>
  );
}

export default App;