import { useState } from "react";

function Emplist() {
    const [empArray, setempArray] = useState([]);

    const [empno, setempno] = useState("");
    const [ename, setename] = useState("");
    const [job, setjob] = useState("");
    const [sal, setsal] = useState("");
    const [deptno, setdeptno] = useState("");
    const [editEmpno, setEditEmpno] = useState("");

    let resultArray2 = empArray.map((item) => {
        return <tr>
            <td>   {item.empno}  </td>
            <td>   {item.ename}  </td>
            <td>   {item.job}  </td>
            <td>   {item.sal}  </td>
            <td>   {item.deptno}</td>
            <td>  
            <a href="javascript:void(0);" 
                   onClick={() => deleteemp_click(item.empno)}>Delete</a>

            </td>
            <td><a href="javascript:void(0);" 
                   onClick={() => updateemp_click(item.empno)}>Edit</a></td>
        </tr>
    });

    function getempButton_click() {
        let tempArray = [
            { empno: 10, ename: "Devi vara prasad", job: "developer", sal: 18000, deptno: 1 },
            { empno: 20, ename: "Malli", job: "tester", sal: 20000, deptno: 2 },
            { empno: 30, ename: "priya", job: "HR", sal: 30000, deptno: 3 },
            { empno: 40, ename: "Sesi", job: "Q/A Engineer", sal: 22000, deptno: 4 },
        ];

        setempArray(tempArray);
    }


    function addempButton_click() {

        let tempArray = [...empArray];

        if (editEmpno) { 
            let index = tempArray.findIndex(item => item.empno === editEmpno);
            tempArray[index] = { empno, ename, job, sal, deptno };
        } else {

        let deptObj = {};
        deptObj.empno = empno;
        deptObj.ename = ename;
        deptObj.job = job;
        deptObj.sal = sal;
        deptObj.deptno = deptno;
        tempArray.push(deptObj);
    }
        setempArray(tempArray);


        setempno("");
        setename("");
        setjob("");
        setsal("");
        setdeptno("");


    }

    function deleteemp_click(empno) {

        let tempArray = [...empArray];    // cloning original array into temp array
        let index = tempArray.findIndex(item => item.empno === empno);
        tempArray.splice(index, 1);
        setempArray(tempArray);
    }
    function updateemp_click(empno) {

        let employeeToEdit = empArray.find(item => item.empno === empno);

        setempno(employeeToEdit.empno);
        setename(employeeToEdit.ename);
        setjob(employeeToEdit.job);
        setsal(employeeToEdit.sal);
        setdeptno(employeeToEdit.deptno);

        setEditEmpno(empno);


    }

    return (
        <>

            <input type="text" placeholder="employee Number" value={empno} onChange={(e) => setempno(e.target.value)} />
            <input type="text" placeholder="employee Name" value={ename} onChange={(e) => setename(e.target.value)} />
            <input type="text" placeholder="JOB" value={job} onChange={(e) => setjob(e.target.value)} />
            <input type="text" placeholder="salary" value={sal} onChange={(e) => setsal(e.target.value)} />
            <input type="text" placeholder="Dept No" value={deptno} onChange={(e) => setdeptno(e.target.value)} />
            <input type="button" onClick={addempButton_click} value="Add Dept" />
            <hr />

            <input type="button" onClick={getempButton_click} value="Get employee details" />
            <table border="2" width="400" cellspacing="0" cellpadding="5">
                <tr>
                    <th>EMPLOYEE NUMBER</th>
                    <th>EMPLOYEE NAME</th>
                    <th>JOB</th>
                    <th>SALARY</th>
                    <th>DEPT NO</th>
                    <th>REMOVE RECORD</th>
                    <th>UPDATE</th>
                </tr>
                {resultArray2}
            </table>
        </>
    );
}

export default Emplist;