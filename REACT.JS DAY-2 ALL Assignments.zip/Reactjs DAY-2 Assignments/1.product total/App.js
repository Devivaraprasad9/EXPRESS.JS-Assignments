import React from 'react';
//import Productlist from './productlist'
import Login from './login'


function App() {
  return (
    <>
      <h3 align="center">Welcome to QUESTION-1 on product total calculation </h3>
      <hr />
      
      <Login />
      
    </>
  );
}

export default App;