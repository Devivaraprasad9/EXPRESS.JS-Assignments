import { useState } from "react";

function Login() {
    const [uproduct, setUproduct] = useState("");
    const [quantity, setquantity] = useState("");
    const [price, setprice] = useState("")
    const [result, setResult] = useState("");


    function buttonClick() {
       

      setResult(quantity*price);
        
        

    }

    return (
        <>
            
           
            <fieldset>
                <legend>CALCULATOR FOR TOTAL PRICE</legend>
                product : <input type="text"  value={uproduct} onChange={(e) => setUproduct(e.target.value)} /> <br />
                quantity : <input type="text"  value={quantity} onChange={(e) => setquantity(e.target.value)} />  <br />
                price : <input type="text"  value={price} onChange={(e) => setprice(e.target.value)} /> <br />
                <input type="button" onClick={buttonClick} value="Get Total" />
                <p>THE TOTAL PRICE IS :{result}</p>
            </fieldset>

        </>
    );
}

  
  export default Login;